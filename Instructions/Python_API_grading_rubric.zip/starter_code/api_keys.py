# OpenWeatherMap API Key
weather_api_key = "c3f8c471a7403217570d19447718502e"

# Google API Key
g_key = "AIzaSyAJMpDCpK32A_5dza0CN1BBWT9EMpS7ThU"
